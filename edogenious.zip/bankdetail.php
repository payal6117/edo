<?php require("view/header.php"); ?>



<section class="main_section bank_detail_section">
    <h1 class="heading">Fee Payment</h1>
    <div class="content">
        
        <div class="card">
            <!-- online -->
        <div>
           <h1 class="mb-3">Online Payment</h1>
            <div class="bank_item ">
                <p class=" pb-3 fw-bold">edugenius@icici /
                    <br> GooglePay /  PhonePay: <br> <br> 9801694485</p>
                
            </div>
        </div>


           <!-- bank -->
            <h1 class="mb-4">By Bank Payment</h1>
            <div class="bank_item"><i class="fa fa-credit-card-alt" aria-hidden="true"></i>
                <h2 class="fw-bold">Name Of Bank: ICICI Bank  <br></h2>
                <p> </p>
            </div>

            <div class="bank_item">
                <h2 class="fw-bold">IFSC Code: ICIC0000307</h2>
                <p></p>
            </div>
            

            <div class="bank_item">
                <h2 class="fw-bold">Branch: Kankarbagh</h2>
                <p></p>
            </div>

          
        </div>
    </div>
</section>

<?php require("view/footer.php"); ?>
