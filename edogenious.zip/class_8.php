<?php require("view/header.php"); ?>

    <section class=" main_section   class_section" id="">
        <h1 class="heading">Class 8</h1>

        <!-- <div class="content">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni ipsum optio nulla esse reprehenderit quae dolorum numquam porro deserunt est, quibusdam beatae recusandae similique, totam, aspernatur aliquam? Hic aperiam tempora delectus quos? Sit amet reprehenderit deserunt voluptas ullam animi molestiae molestias laboriosam, enim at nemo fuga odit eaque, veniam officiis?</p>
        </div> -->

        <div class="content_image d_grid d_grid_6 grid_img">
            <div class="class_item">
                <img src="https://cdn.wallpapersafari.com/55/34/Nn5k9r.jpg" alt="">
                <p>Mathematic</p>
            </div>
            <div class="class_item">
                <img src="https://www.drnjhacollegerampura.in/wp-content/uploads/2020/07/hand-drawn-science-education-background_23-2148494536.jpg" alt="">
                <p> Science & Technology</p>
            </div>

            <div class="class_item">
                <img src="https://t3.ftcdn.net/jpg/03/70/42/66/360_F_370426690_Pejt9KxjWTHPklsKwripaxr0iA17zupF.jpg" alt="">
                <p> English</p>
            </div>

            <div class="class_item">
                <img src="https://media.istockphoto.com/photos/hindi-language-and-culture-concept-picture-id953423154?k=20&m=953423154&s=612x612&w=0&h=YU_9wWu_XTAjvj3iCJ--3nnbYdbSuQOpvwqqhcuTQro=" alt="">
                <p> Hindi</p>
            </div>

            <div class="class_item">
                <img src="https://odishabytes.com/wp-content/uploads/2020/07/social-science1.png" alt="">
                <p> Social Science</p>
            </div>

            <div class="class_item">
                <img src="https://odishabytes.com/wp-content/uploads/2020/07/social-science1.png" alt="">
                <p>  Additional Subject</p>
            </div>

            <div class="class_item">
                <img src="https://d2cyt36b7wnvt9.cloudfront.net/exams/wp-content/uploads/2021/11/12193205/Marketing-Team-BLOG-FEATURED-IMAGE-1200-X-800-30.png" alt="">
                <p>  Additional Subject</p>
            </div>

            

        </div>
    </section>