<?php
                    require 'dbCon.php';
                    
                    if(isset($_POST['submit'])){
                        // var_dump($_POST['hidden']);
                        // exit();
                            if(!empty($_POST['fname']) && !empty($_POST['phone']) && !empty($_POST['email']) && !empty(['school']) && !empty(['class']) && !empty(['messages'])){

                                $fname = $_POST['fname'];
                                $phone = $_POST['phone'];
                                $email = $_POST['email'];
                                $school = $_POST['school'];
                                $class = $_POST['class'];
                                $messages = $_POST['messages'];
    
                                $query = "insert into contact_info(fname,phone,email,school,class,messages)values('$fname','$phone','$email','$school','$class','$messages')";
    
                                $run = mysqli_query($con,$query);
    
                                if($run){
                                    if($_POST['hidden']=="index"){
                                        echo '<p>Form Submitted</p>';    
                                        header("Location:index.php");        
                                    }else if($_POST['hidden']=="contactUs"){
                                        echo '<p>Form Submitted</p>';
                                        header("Location:contact_page.php");        
                                    }

                                }else{
                                    echo '<p>Form not submitted</p>';
                                }
                            }else{
                                echo '<p>All fields required</p>';
    
                            }

                    }
                    ?>