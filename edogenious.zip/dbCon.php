<?php

$server = 'localhost';
$username = 'root';
$password = "";
$dbName = "edugenius";

$con = mysqli_connect($server,$username,$password,$dbName);