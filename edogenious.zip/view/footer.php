




<footer class=" footer_section " >
    <div class="content d_grid">
        <div class="item  about_logo_sec">
            
                <a href="index.php" class="brand">EduGenius Coaching <br> Classes</a>
                <p class="about_edo_text"  >EduGenius Coaching Classes, A Leading Consultancy And The Best Coaching For 8th To 12th Standard Candidates, Is There To Provide Expert Guidance, Consultancy And Counseling To Aspirants For A Better Career And Future</p>
           
        </div>
    
        <div class="item navigation_links">
            <ul>
                <li class="nav_links"><h1>Navigation Links</h1></li>
                <li class="nav_links"><a href="./about_page.php">
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>About</a>
                </li>
            
                <li class="nav_links"><a href="./photo_page.php">
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>Photos</a>
                </li>
                <li class="nav_links"><a href="./bankdetail.php">
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>Fee Payments</a>
                </li>
                <li class="nav_links"><a href="./result_reward.php">
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>Results & Rewards</a>
                </li>
                <li class="nav_links"><a href="./contact_page.php">
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>Contact Us</a>
                </li>
            </ul>
        </div>
    
        <div class="item navigation_links">
            <ul>
                <li class="nav_links"><h1>STUDY MATERIALS</h1></li>
                <!-- <li class="nav_links"><a href="./class_6.php"> 
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>Neet & IIT-JEE</a>
                </li> -->
                <li class="nav_links"><a href="./class_7.php"> 
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>Class 7th </a>
                </li>
                <li class="nav_links"><a href="./class_8.php"> 
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>Class 8th </a>
                </li>
                <li class="nav_links"><a href="./class_9.php"> 
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>Class 9th </a>
                </li>

                <li class="nav_links"><a href="./class_10.php"> 
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>Class 10th </a>
                </li>

                <li class="nav_links"><a href="./class_11.php"> 
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>Class 11th </a>
                </li>

                <li class="nav_links"><a href="./class_12.php"> 
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>Class 12th </a>
                </li>
            </ul>
        </div>
    
        <div class="item">
            <ul>
                <li class="socia_links"><h1>Get In Touch</h1></li>
                 <span class="social_media">
                    
                       <li class="socia_links">
                            <a href="https://api.whatsapp.com/send?phone=919155364077&app=facebook&entry_point=page_cta"
                             target="_blank"><i class="fa  fa-whatsapp icons " aria-hidden="true"></i>
                        </a></li>

                        <li class="socia_links">
                            <a href="https://www.facebook.com/EduGenius-Coaching-Classes-108231834640639/"
                             target="_blank">
                                <i class="fa  fa-facebook  icons "  aria-hidden="true"></i>
                        </a></li>

                        <li class="socia_links">
                            <a href="https://www.youtube.com/channel/UCKkZI7QsFc4yaXqSE0Kz76w" target="_blank">
                                <i class="fa  fa-youtube  icons "  aria-hidden="true"></i>
                        </a></li>

                 </span>
                 

                 <div class="location">
                     <div>
                         <p> 108 Commercial Space, NBCC Towers, Sector-7, Near Agam Kuan Police Station, Patna </p>
                       
                         <br>
                             <a href="email:edutobeagenius@gmail.com"><p > Email: <span style="text-transform:lowercase" >edutobeagenius@gmail.com</span> </p></a>

                     
                        </div>
                 </div>
            </ul>
        </div>

        <!-- <div class="item">d</div> -->
    </div>

</footer>


</body>
</html>