 <?php require("view/header.php"); ?>


 
 <div class="position-absolute arrow_up quick_enquiry_4" > 
    <li>
        <a href="./#top" class="quick_enquiry_link_arrow_up"> 
        <i class="fa fa-arrow-up" aria-hidden="true"></i>
     </a>
    </li>
</div>

  
  <!-- -------------------------------------------- banner section ---------------------------------------------------
  ----------------------------------------------------------------------------------------------------------------------- -->
  <section class="banner " id="top">
      <div class="swiper banner_swiper ">
          <div class="swiper-wrapper">
            <div class="swiper-slide"  style="background-image: url(./img/2.jpeg); height: 100vh;"> </div>
            <div class="swiper-slide"  style="background-image: url(./img/7.jpeg); height: 100vh;"></div>
            <div class="swiper-slide"  style="background-image: url(./img/33.jpeg); height: 100vh;"></div>
            <div class="swiper-slide"  style="background-image: url(./img/66.jpeg); height: 100vh;"></div>
            <div class="swiper-slide"  style="background-image: url(./img/77.jpeg); height: 100vh;"></div>
          </div>
          <div class="swiper-button-next slider_icon"></div>
          <div class="swiper-button-prev slider_icon"></div>
          
      </div>
  </section>

  <!-- --------------------------------------------- Quick Links section --------------------------------------------------------------------------------------------- -->

  <section class=" main_section quick_link__section ">
      <!-- <h1 class="heading">Quick Links</h1> -->

      <div class="quick_item quick_link_d_grid ">
          <div class="item">
              <a href="#landing_form_page" >Register for courses <br>   <i class="fa fa-cloud-download" aria-hidden="true"></i>    </a >
          </div>
          <div class="item">
              <a href="./edugenius.php" >scholorship tests <br>  <i class="fa fa-cloud-download" aria-hidden="true"></i> </a >
          </div>
          <div class="item">
              <a href="./edugenius.php" >test results <br>  <i class="fa fa-cloud-download" aria-hidden="true"></i> </a >
          </div>
          <div class="item">
              <a href="#landing_form_page" >faq <br>  <i class="fa fa-cloud-download" aria-hidden="true"></i> </a >
          </div>
          <div class="item">
              <a href="#landing_form_page" >downloads <br>  <i class="fa fa-cloud-download" aria-hidden="true"></i> </a >
          </div>
          <div class="item">
            <a href="#landing_form_page" >Blogs <br>  <i class="fa fa-cloud-download" aria-hidden="true"></i> </a >
        </div>
      </div>
  </section>  

  <!-- -------------------------------------------- about section ---------------------------------------------------
  ----------------------------------------------------------------------------------------------------------------------- -->
    <section class=" main_section about__section  " id="testresult">
        <div class="about_content d_grid ">
            <div class="item item_left">
                <img src="./img/7.jpeg" alt="#" id="imgg about_img" >
            </div>
            <div class="item item_right">
                <div class="right_content">
                    <h1 class="heading" id="about_heading" >About Our Institute</h1>
                    <p>
                    The journey started with just 2 students in way back in 2014 under a small roof. We were low with the infrastructure but not with the confidence, purpose, enthusiasm and perseverance.
                    <br><br>

                    Today we are enriched with state of the art infrastructure like spacious and comfortable classrooms, young and experienced teachers that include doctors, IITians, NITians, etc., smart classrooms, hygienic wash rooms and what not.
                    <br><br>
                    We are giving good results continuously ever since we have started the journey.
                    </p>


                    <ul>
                       <li><button class="common_btn apply_now_btn">
                            <a href="./about_page.php" >Read More</a>
                        </button></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

   <!-- -------------------------------------------- WHY ? section ---------------------------------------------------
  ----------------------------------------------------------------------------------------------------------------------- -->

  <section class=" main_section why_choose_us__section ">
      <div class=" d_grid ">
         
          <div class="item item_right">
          <h1 class="heading " id="" >Why EduGenius?</h1>
              <div class="right_content">
                  
                  <div class="title_text">
                        <p> •	Foundation classes right from class 7 onwards</p> 
                        <p> •	Competitive class environment  </p> 
                        <p> •	Individual mentoring  </p> 
                        <p> •	Course completion on time </p> 
                        <p> •	Best teachers (Doctors, Engineers, etc.) </p> 
                        <p> •	Comprehensive study materials</p>
                  </div>
            




                  <ul>
                      <div class="why_choose_us_btn">
                          <li><button class="common_btn">
                              <a href="./about_page.php" >read more</a>
                          </button></li>
                          <li><button class="common_btn apply_now_btn">
                              <a href="#landing_form_page" >ADMISSIONS (APPLY ONLINE)</a>
                          </button></li>
                      </div>
                  </ul>
              </div>
          </div>

          <div class="item item_left ">
                <iframe class="why_choose_vdo" width="560" height="315" src="https://www.youtube.com/embed/j66HFiz0yjY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>
      </div>
 </section>





     <!-- -------------------------------------------- admission center section ---------------------------------------------------
  ----------------------------------------------------------------------------------------------------------------------- -->
  <section class=" main_section admission__center  ">
      <div class="content d_grid">
            <div class="item">
              <div class="text_content">
                  <i class="fa fa-graduation-cap" aria-hidden="true"></i>
                  <h2 class="course_name"> <a href=""> EduGenius Coaching Classes </a> </h2>
                  <p class="course_descript">
                     We are Enriched With State Of The Art Infrastructure Like Spacious And Comfortable Classrooms, Young And Experienced Teachers.
                    
                  </p>

              </div>
          </div>
          
          <div class="item">
              <div class="text_content">
                  <i class="fa  fa-map-marker" aria-hidden="true"></i>
                  <h2 class="course_name"> <a href="#">Admission Center 1</a> </h2>
                  <h2 class="course_name"> <a href="#"></a> </h2>
                  <p class="course_descript">
                   <span style="text-decoration: underline;">EduGenius Coaching Classes</span>
                  <br><br>
                Mangal Chawk, Khemnichak, Patna - 800027 

                  </p>

              </div>
          </div>

          <div class="item">
              <div class="text_content">
                  <i class="fa  fa-map-marker" aria-hidden="true"></i>
                  <h2 class="course_name"> <a href="#">Admission Center 2</a> </h2>
                   
                  <p class="course_descript">
                    <span style="text-decoration: underline;">EduGenius Coaching Classes</span>
                   <br><br>
                    NBCC Tower, 70 Feet Road, Vijay Nagar Kankarbagh, Patna - 800026
 
                   </p>

              </div>
          </div>
      </div>
  </section>

  <!-- --------------------------------------------- our courses section ---------------------------------------------------
  ----------------------------------------------------------------------------------------------------------------------- -->
  
  <section class=" main_section courses__section ">
      <h1 class="heading">Our Courses</h1>
      <div class="course_content d_grid">

        <div class="course_item">
            <!-- <img src="./img/22.jpg" alt="#"> -->
            
            <div class="text_content">
                <h2 class="course_name" id="neet_it_course">Foundation Courses For NEET & IIT-JEE</h2>
                <p class="course_descript">
                    Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem     
                </p>

                <div class="course_btn">
                    <ul >
                        <li><button class="common_btn">
                            <a href="./class_6.php/class_6.php" >Read More</a>
                        </button></li>
                    </ul>   
                </div>
            </div>
        </div>

        <div class="course_item">
            <!-- <img src="./img/22.jpg" alt="#"> -->
            
            <div class="text_content">
                <h2 class="course_name"> Class 7th</h2>
                <p class="course_descript">
                    Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem 
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel necessitatibus, 
                </p>

                <div class="course_btn">
                    <ul >
                        <li><button class="common_btn">
                            <a href="./class_6.php" >Read More</a>
                        </button></li>
                    </ul>   
                </div>
            </div>
        </div>

        <div class="course_item">
            <!-- <img src="./img/22.jpg" alt="#"> -->
            
            <div class="text_content">
                <h2 class="course_name"> Class 8th</h2>
                <p class="course_descript">
                    Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem 
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel necessitatibus, 
                </p>

                <div class="course_btn">
                    <ul >
                        <li><button class="common_btn">
                            <a href="./class_6.php" >Read More</a>
                        </button></li>
                    </ul>   
                </div>
            </div>
        </div>

        <div class="course_item">
            <!-- <img src="./img/22.jpg" alt="#"> -->
            
            <div class="text_content">
                <h2 class="course_name"> Class 9th / 10th</h2>
                
                <p class="course_descript">
                    Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem 
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel necessitatibus, 
                </p>

                <div class="course_btn">
                    <ul >
                        <li><button class="common_btn">
                            <a href="./class_6.php" >Read More</a>
                        </button></li>
                    </ul>   
                </div>
            </div>
        </div>

        <div class="course_item">
            <!-- <img src="./img/22.jpg" alt="#"> -->

            
            <div class="text_content">
                <h2 class="course_name"> Class 11th / 12th</h2>
                <p class="course_descript">
                    Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem 
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel necessitatibus, 
                </p>

                <div class="course_btn">
                    <ul >
                        <li><button class="common_btn">
                            <a href="./class_6.php" >Read More</a>
                        </button></li>
                    </ul>   
                </div>
            </div>
        </div>
      </div>
 
    </div>
  </section>




  <!-- ---------------------------------------------  Form section 
 ------------------------------------------------------------------------------------------ -->
<section class="main_section admision_form d_grid main ">
    <div class="item">
        <div class="swiper banner_swiper swipee " >
            <div class="swiper-wrapper">
              <div class="swiper-slide "  style="background-image: url(./img/7.jpeg)">
            </div>
              <!-- <div class="swiper-slide "  style="background-image: url(./img/22.jpg); ;"></div>
              <div class="swiper-slide "  style="background-image: url(./img/22.jpg); ;"></div>
              <div class="swiper-slide "  style="background-image: url(./img/22.jpg); ;"></div>
              <div class="swiper-slide "  style="background-image: url(./img/22.jpg); ;"></div> -->
            </div>
            <!-- <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div> -->
            
        </div>
    </div>
    <div class="item" id="landing_form_page">
        <div class="item form_left">
            <h1 class="heading" >Request Admissions Information</h1>
            
            <form action="DataInsert.php" method="POST" class="form" id="contact-form">
               <ul>
                   <input type="hidden" value="index" name="hidden">
                   <li><input type="text" name="fname" id="username" placeholder="Your Name" required></li>
                   <li><input type="text" name="phone" id="phoneno" placeholder="Your Phone No" required></li>
                   <li><input type="text" name="email" id="email" placeholder="Your Email" required></li>
                   <li><input type="text" name="school" id="school" placeholder="School" required></li>
              
                   <div class="choose_class">
                        <select name="class" id="class" required>
                            <option value="">Choose Your Class</option>
                            <option value="seven">7</option>
                            <option value="eight">8</option>
                            <option value="nine">9</option>
                            <option value="ten">10</option>
                        </select>
                   </div>

                   <li><textarea name="messages" id="" cols="30" rows="10" placeholder="Your message (optional)" required></textarea></li>
              
                   <li class="common_btn form_submit_btn"><button type="submit" name="submit">Submit</button></li>
                </ul>
            </form>
         </div>
    </div>
</section>

  <!-- --------------------------------------------- Youtube Videos section 
 ------------------------------------------------------------------------------------------ -->

    <section class=" main_section youtube_vdo_section ">
        <div class=" d_grid  youtube_vdo_section_d_grid">
            <div class="item">
              

                <iframe  class="youtube_vdo" src="https://www.youtube.com/embed/AgSPNsp4EuE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            
            <div class="item">
                <iframe  class="youtube_vdo"  src="https://www.youtube.com/embed/a7KwPSBer7M" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            
            <div class="item">
                <iframe  class="youtube_vdo"  src="https://www.youtube.com/embed/YZ9V07NDRJ4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            
            <div class="item">
                <iframe  class="youtube_vdo"  src="https://www.youtube.com/embed/R2DeHBczUHY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
        
        </div>
    </section>
  
  <!-- --------------------------------------------- testimonial section 
 ------------------------------------------------------------------------------------------ -->

 <section class="main_section testimonial_section   ">
    <h1 class="heading text-left" id="" >Our testimonial</h1>
     <div class="testimonial_content">
      <div class="swiper testimonial_swiper ">
          <div class="swiper-wrapper">
            <div class="swiper-slide item " > 
                <img class="testimonial_image" src="./img/pen.webp" alt="testimonialImage">

                <div class="content">
                    <P>“ definitely an experience worth sharing. I surely hav a lot of points to highlight but i would bring the lights on test concept first papers helps you gain the grip of framing answers. Not to forget the continous support and guidance provided with concept learning. Every student enrolled here will have fun time studying and will experience great personality build.” </P>

                    <div class="testimonial_caption d_grid  ">
                        <div ><p  class="caption_img" ></p> </div>
                        <div class="caption_name">
                            <p>@Aashi Singh</p>
                             <p></p>
                         </div>
                     
                    </div>
                </div>
             </div>
            <div class="swiper-slide item ">
                     <img class="testimonial_image" src="./img/pen.webp" alt="testimonialImage">

                   <div class="content">
                       <P>“I LoVe Edogenius. Because if anyone has done the job of showing me the right path, it is Edogenius. They are known not by their name but by their work. When I took admission So I didn't do that much aspect. More than that, I got support from the Edugenius teacher.” </P>

                       <div class="testimonial_caption d_grid  ">
                           <div ><p  class="caption_img" ></p> </div>
                           <div class="caption_name">
                               <p>@Amit Kumar</p>
                                <p></p>
                            </div>
                        
                       </div>
                   </div>
            </div>
            <div class="swiper-slide item ">
                     <img class="testimonial_image" src="./img/pen.webp" alt="testimonialImage">

                   <div class="content">
                       <P>“Edogenius is a very good school. And its teachers are also very supportive. Let us explain each point till you understand it. Thanks Edogenius.” </P>

                       <div class="testimonial_caption d_grid  ">
                           <div ><p  class="caption_img" ></p> </div>
                           <div class="caption_name">
                               <p>@Raj Kumar Verma</p>
                                <p></p>
                            </div>
                        
                       </div>
                   </div>
            </div>
            <div class="swiper-slide item ">
                     <img class="testimonial_image" src="./img/pen.webp" alt="testimonialImage">

                   <div class="content">
                       <P>“I have had the best experience ever, in Edogenius because all the schools out there do not give you the facility of transparancy, but edogenius gives you. From the teacher to the principal of this school, everyone is a very humble person.” </P>

                       <div class="testimonial_caption d_grid  ">
                           <div ><p  class="caption_img" ></p> </div>
                           <div class="caption_name">
                               <p>@Shilpa</p>
                               
                            </div>
                        
                       </div>
                   </div>
            </div>
            <div class="swiper-slide item ">
                     <img class="testimonial_image" src="./img/pen.webp" alt="testimonialImage">

                   <div class="content">
                       <P>“Whether you want to take admission, or see the result, you will not need to go anywhere, you will be able to do all these things sitting at home. You have to visit” </P>

                       <div class="testimonial_caption d_grid  ">
                           <div ><p  class="caption_img" ></p> </div>
                           <div class="caption_name">
                               <p>@Avni Amit Kumar</p>
                                <p></p>
                            </div>
                        
                       </div>
                   </div>
            </div>
            <div class="swiper-slide item ">
                     <img class="testimonial_image" src="./img/pen.webp" alt="testimonialImage">

                   <div class="content">
                       <P>“You get a chance to study from experts in every subject. People whose teachers are recruited, that is also a very difficult process, through which even the best teachers guide you.” </P>

                       <div class="testimonial_caption d_grid  ">
                           <div ><p  class="caption_img" ></p> </div>
                           <div class="caption_name">
                               <p>@Rupali Gupta  </p>
                            </div>
                        
                       </div>
                   </div>
            </div>
           
           
            </div>

          </div>
        
     </div>
 </section>








































 <script>
            var swiper = new Swiper(".banner_swiper", {
                autoHeight: false,
                spaceBetween: 0,
                loop:true,
                pagination: {
                clickable: true,
                },
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                autoplay: {
                    delay: 3000,
                    disableOnInteraction: false,
                },
                breakpoints: {
                    640: {
                        slidesPerView: 1,
                        spaceBetween: 20,
                    },
                    768: {
                        slidesPerView: 1,
                        // spaceBetween: 40,
                    },
                    1024: {
                        slidesPerView: 1,
                        // spaceBetween: 50,
                    },
                },
            });


            var swiper = new Swiper(".testimonial_swiper", {
                autoHeight: false,
                spaceBetween: 0,
                loop:true,
                pagination: {
                clickable: false,
                },
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                autoplay: {
                    delay: 1000,
                    disableOnInteraction: true,
                },
                breakpoints: {
                    640: {
                        slidesPerView: 3,
                        spaceBetween: 10,
                    },
                    768: {
                        slidesPerView: 3,
                        spaceBetween: 10,
                    },
                    1024: {
                        slidesPerView: 3,
                        spaceBetween: 10,
                    },
                },
            });
        </script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>



<?php require("view/footer.php"); ?>
