    
<?php require("view/header.php"); ?>



    <section class=" main_section  contact_page_section" id="">
        <h1 class="heading">Contact Us</h1>

        <div class=" d_grid content ">
                <div class="item">
                    <a href="tel:+91 7903 3957 41">
                    <i class="fa fa-phone" aria-hidden="true"></i> <br> +91 7739716455 </a> <br>
                    
                    <a href="tel:+919155364077" style="margin-left:10px"> +91 9155 3640 77</a><br>
                </div>
                
                <div class="item">
                   <a href="mailto:edutobeagenius@gmail.com">
                        <i class="fa fa-envelope" aria-hidden="true"
                       ></i>  <span  style=" text-transform:lowercase">  edutobeagenius@gmail.com</span></a>
                </div>
        </div>
    </section>


    <section class="main_section admision_form d_grid main ">
        <div class="item">
            <div class="swiper banner_swiper swipee " >
                <div class="swiper-wrapper">
                    <div class="swiper-slide "  style="background-image: url(./img/7.jpeg)"></div>
                  <!-- <div class="swiper-slide "  style="background-image: url(./img/22.jpg)"></div>
                  <div class="swiper-slide "  style="background-image: url(./img/22.jpg); ;"></div>
                  <div class="swiper-slide "  style="background-image: url(./img/22.jpg); ;"></div>
                  <div class="swiper-slide "  style="background-image: url(./img/22.jpg); ;"></div>
                  <div class="swiper-slide "  style="background-image: url(./img/22.jpg); ;"></div> -->
                </div>
                <!-- <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div> -->
                
            </div>
        </div>
        <div class="item">
            <div class="item form_left">
                <h1 class="heading">Request Admissions Information</h1>
                <form action="#" class="form">
                   <ul>
                       <li><input type="text" name="fname" id="username" placeholder="Your Name" required></li>
                       <li><input type="text" name="fname" id="phoneno" placeholder="Your Phone No" required></li>
                       <li><input type="text" name="fname" id="email" placeholder="Your Email" required></li>
                       <li><input type="text" name="fname" id="school" placeholder="School" required></li>
                  
                       <div class="choose_class">
                            <select name="" id="" required>
                                <option value="">Choose Your Class</option>
                                <option value="seven">7</option>
                                <option value="eight">8</option>
                                <option value="nine">9</option>
                                <option value="ten">10</option>
                            </select>
                       </div>
    
                       <li><textarea name="" id="" cols="30" rows="10" placeholder="Your message (optional)" required></textarea></li>
                  
                       <li class="common_btn form_submit_btn"><button type="submit" >Submit</button></li>
                    </ul>
                </form>
             </div>
        </div>
    </section>


    <section class=" main_section  address_page_section" id="">
        <h1 class="heading">Main Head Office:</h1>

        <div class=" d_grid address_content ">
                <div class="item"> 
                    <ul>
                        <li><h1> <i class="fa fa-location-arrow " aria-hidden="true"></i> 
                        EduGenius Coaching Classes
                           </h1>
                            <p>
                            NBCC Tower, 70 Feet Road, Vijay Nagar Kankarbagh, Patna - 800026
                            </p>
                        </li>

                        <li>
                            <a href="tel: +917739716455">
                              <i class="fa fa-phone" aria-hidden="true"></i> +91 7739 7164 55,
                            </a>
                           
                            <a href="tel: +91 9155 3640 77" style="margin-left:10px"> +91 9155 3640 77</a>
                        </li>
                    
                        <li>
                        <a href="mailto:edutobeagenius@gmail.com"> <i class="fa fa-envelope" aria-hidden="true"></i> <span style=" text-transform:lowercase"> edutobeagenius@gmail.com </span></a>
                        </li>
                    </ul>
                   

                </div>
                <div class="item">
                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14393.777498089963!2d85.1685175!3d25.590146!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x9e5a39ecda32efeb!2sEduGenius%20Coaching%20Classes!5e0!3m2!1sen!2sin!4v1650102416616!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="locate_map"></iframe>
                  
                </div>
                
        </div>
    </section>
 <!-- -------------------------------------------- admission center section ---------------------------------------------------
  ----------------------------------------------------------------------------------------------------------------------- -->
  <section class=" main_section admission__center  ">
      <div class="content d_grid">
            <div class="item">
              <div class="text_content">
                  <i class="fa fa-graduation-cap" aria-hidden="true"></i>
                  <h2 class="course_name"> <a href=""> EduGenius Coaching Classes </a> </h2>
                  <p class="course_descript">
                     We are Enriched With State Of The Art Infrastructure Like Spacious And Comfortable Classrooms, Young And Experienced Teachers.
                    
                  </p>

              </div>
          </div>
          
          <div class="item">
              <div class="text_content">
                  <i class="fa fa-map-marker" aria-hidden="true"></i>
                  <h2 class="course_name"> <a href="#">Admission Center 1</a> </h2>
                  <h2 class="course_name"> <a href="#"></a> </h2>
                  <p class="course_descript">
                   <span style="text-decoration: underline;">EduGenius Coaching Classes</span>
                  <br><br>
                  108 Commercial Space, NBCC Towers, Sector-7, Near Agam Kuan Police Station, Patna 

                  </p>

              </div>
          </div>

          <div class="item">
              <div class="text_content">
                  <i class="fa fa-map-marker" aria-hidden="true"></i>
                  <h2 class="course_name"> <a href="#">Admission Center 2</a> </h2>
                   
                  <p class="course_descript">
                    <span style="text-decoration: underline;">EduGenius Coaching Classes</span>
                   <br><br>
                   108 Commercial Space, NBCC Towers, Sector-7, Near Agam Kuan Police Station, Patna 
 
                   </p>

              </div>
          </div>
      </div>
  </section>
   
</div>


    

    <script>
        var swiper = new Swiper(".banner_swiper", {
                autoHeight: false,
                spaceBetween: 0,
                pagination: {
                clickable: true,
                },
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                autoplay: {
                    delay: 3000,
                    disableOnInteraction: false,
                },
                breakpoints: {
                    640: {
                        slidesPerView: 1,
                        spaceBetween: 20,
                    },
                    768: {
                        slidesPerView: 1,
                        // spaceBetween: 40,
                    },
                    1024: {
                        slidesPerView: 1,
                        // spaceBetween: 50,
                    },
                },
            });

    </script>

    
<?php require("view/footer.php"); ?>