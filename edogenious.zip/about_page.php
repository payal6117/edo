<?php require("view/header.php"); ?>

    <section class=" main_section about__section about_page_section" id="about_page_section">
        <h1 class="heading">About Us</h1>
        
        <div class="course_content about_content d_grid   ">
            <div class="item item_left">
                <img src="./img/7.jpeg" alt="#" id="imgg about_img" >
            </div>
            
            <div class="item item_right">
                <div class="right_content">
                    <h1 class="heading" id="about_heading" >About Our Institute</h1>
                    <p>
                        The journey started with just 2 students in way back in 2014 under a small roof. We were low with the infrastructure but not with the confidence, purpose, enthusiasm and perseverance.
                        <br><br>

                        Today we are enriched with state of the art infrastructure like spacious and comfortable classrooms, young and experienced teachers that include doctors, IITians, NITians, etc., smart classrooms, hygienic wash rooms and what not.
                        <br><br>
                        We are giving good results continuously ever since we have started the journey.

                        <br><br>
                        Some of them are :-  
                        <br>
                           <ul>
                               <li ><p> • X boards-	98.7% heighest so far  95-96% is the average</p></li>
                               <li ><p> • Olympiads- All kinds of medals</p></li>
                               <li ><p> • NEET (Medicals)	Our students are in IGIMS, PMCH, NMCH, etc.</p></li>
                               <li ><p> • IIT-JEE/NIT (Engineering)	 Different IITs, DU, All NITs, etc.</p></li>
                               <li ><p> • Up to 100% Scholarships in national level tests</p></li>
                               <li ><p> • Perfect score of 100 marks in all subjects in boards</p></li>
                               <li ><p> • We are not boasting but excellence is the routine here. We believe that practice is the key of success and therefore our mantra is </p></li>
                           </ul>

                    </p>

                    <ul>
                        <li><button class="common_btn apply_now_btn">
                            <a href="#" > APPLY ONLINE</a>
                        </button></li>
                    </ul>
                </div>
            </div>
        </div>



        <div class="course_content about_content d_grid   ">
            <div class="item item_left d_heading">
                <h2 class="heading" id="" >
                you are one steps away from your children future. So Call now and book your Seat. we have limited seat.
                </h2>
            </div>
            
            <div class="item item_right">
                <div class="right_content">
                    
                    <div class="item">
                        <div class="swiper banner_swiper swipee " >
                            <div class="swiper-wrapper">
                              <div class="swiper-slide ">
                                  <img src="./img/33.jpeg" alt="">
                              </div>
                              <!-- <div class="swiper-slide " >  <img src="./img/2.jpg" alt=""></div>
                              <div class="swiper-slide " >  <img src="./img/2.jpg" alt=""></div>
                              <div class="swiper-slide " >  <img src="./img/2.jpg" alt=""></div>
                              <div class="swiper-slide " >  <img src="./img/2.jpg" alt=""></div> -->
                            </div>
                            <!-- <div class="swiper-button-next"></div>
                            <div class="swiper-button-prev"></div> -->
                            
                        </div>
                </div>
            </div>
        </div>
        </div>
    </section>


     <!-- -------------------------------------------- WHY ? section ---------------------------------------------------
  ----------------------------------------------------------------------------------------------------------------------- -->

  <section class=" main_section why_choose_us__section   " id="why_choose_us__section">
    <div class=" d_grid ">
       
        <div class="item item_right">
        <h1 class="heading " id="" >Why Edugenius?</h1>
            <div class="right_content">
                  
                <div class="title_text">
                    <p> •	Foundation classes right from class 7 onwards</p> 
                    <p> •	Competitive class environment  </p> 
                    <p> •	Individual mentoring  </p> 
                    <p> •	Course completion on time </p> 
                    <p> •	Best teachers (Doctors, Engineers, etc.) </p> 
                    <p> •	Comprehensive study materials</p>
                </div>

            </div>
        </div>

        <div class="item item_left ">
            <iframe class="why_choose_vdo_mob" width="560" height="315" src="https://www.youtube.com/embed/j66HFiz0yjY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
    </div>
</section>

<section class="apply_now_section" id="apply_now_section">
    <div class="btn">

     <div class="para ">
        <p style="color:#fff">
        Where there is no transparency. Never put your children in such a school. Because by doing this you are playing with the future of your child. We will give complete information about your child's growth with complete transparency. check anytime your children growth with  <br> <br>
        <mark style="font-weight: 700;">EDUGENIUS Coaching Classes Classes</mark>
        </p>
     </div>
        

        <ul>
            <li><button class="common_btn apply_now_btn " id="about_apply_now">
                <a href="./contact_page.php" > APPLY ONLINE</a>
            </button></li>
        </ul>
    </div>
</section>




    <script>
        var swiper = new Swiper(".banner_swiper", {
                autoHeight: false,
                spaceBetween: 0,
                pagination: {
                clickable: true,
                },
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                autoplay: {
                    delay: 3000,
                    disableOnInteraction: false,
                },
                breakpoints: {
                    640: {
                        slidesPerView: 1,
                        spaceBetween: 20,
                    },
                    768: {
                        slidesPerView: 1,
                        // spaceBetween: 40,
                    },
                    1024: {
                        slidesPerView: 1,
                        // spaceBetween: 50,
                    },
                },
            });

    </script>




<?php require("view/footer.php"); ?>