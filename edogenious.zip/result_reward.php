<?php require("view/header.php"); ?>


<section class="main_section result_reward">
    <div class="rewardContainer bg-">
    <h1 class="heading">Results & Rewards</h1>

        <!-- <div class="bannerSection">
            <h1></h1>
        </div> -->
        <div class="coursesDetails">    
            <!-- <h1>YOUR RESULT AND REWARDS</h1> -->
            <div class="row1">
                
            <div class="row2">
                <div class="item">
                    <div class="card">
                        <i class="fa fa-id-badge rewardIcon" aria-hidden="true"></i>
                        <div class="card-body">
                          <p>Here, the children who study well and get proficiency in their field, that is, the children who bring the best results according to their ability.</p>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="card">
                        <i class="fa fa-cube" aria-hidden="true"></i>
                        <div class="card-body">
                            <p>we honor them with rewards from time to time</p>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="card">
                        <i class="fa fa-bandcamp" aria-hidden="true"></i>
                        <div class="card-body">
                            <p> they give their best, in study and in life. Always think ahead</p>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="card">
                        <i class="fa fa-cubes" aria-hidden="true"></i>
                        <div class="card-body">
                           <p>The reward is just an excuse, in fact we have to awaken the motivation inside the children.</p>
                        </div>
                       
                    </div>
                </div>
            </div>

        </div>

    </div>
    </section>

    <?php require("view/footer.php"); ?>