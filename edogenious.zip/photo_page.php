<?php require("view/header.php"); ?>


<section class=" main_section photo_section " id="photo_section">
    <h1 class="heading">Photos</h1>

    <div class="grid_img  ">
     
        <div class="vdo_item">
            <img src="./img/1.jpeg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/3.jpeg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/4.jpeg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/5.jpeg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/6.jpeg" alt="photos">
        </div>

        <div class="vdo_item">
            <img src="./img/8.jpeg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/2.jpeg" alt="photos">
        </div>
        
        <!--  -->
        <div class="vdo_item">
            <img src="./img/2.jpeg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/2.jpeg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/2.jpeg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/2.jpeg" alt="photos">
        </div>
        
        <!--  -->
        <div class="vdo_item">
            <img src="./img/7.jpeg" alt="photos">
        </div>

        <div class="vdo_item">
            <img src="./img/8.jpeg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/9.jpeg" alt="photos">
        </div>

        <div class="vdo_item">
            <img src="./img/10.jpeg" alt="photos">
        </div>

        <div class="vdo_item">
            <img src="./img/11.jpeg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/12.jpeg" alt="photos">
        </div>
    </div>
</section>

<?php require("view/footer.php"); ?>